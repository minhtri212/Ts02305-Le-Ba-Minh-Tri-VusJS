import { createRouter, createWebHistory } from 'vue-router'

import Login from '../views/Login.vue'
import Register from '../views/Register.vue'
import Posts from '../views/Posts.vue'
import Profile from '../views/Profile.vue'

const routes = [
  { path: '/', component: Login },
  { path: '/register', component: Register },
  { path: '/posts', component: Posts },
  { path: '/profile', component: Profile }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
