<template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">SOF308</a>

      <div class="navbar-nav">
        <router-link class="nav-link" to="/">Đăng nhập</router-link>
        <router-link class="nav-link" to="/register">Đăng ký</router-link>
        <router-link class="nav-link" to="/posts">Bài viết</router-link>
        <router-link class="nav-link" to="/profile">Cá nhân</router-link>
      </div>
    </div>
  </nav>
</template>
