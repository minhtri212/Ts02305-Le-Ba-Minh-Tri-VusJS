<template>
  <h3>Đăng nhập</h3>

  <input class="form-control mb-2" v-model="email" placeholder="Email">
  <input class="form-control mb-2" type="password" v-model="password" placeholder="Mật khẩu">

  <button class="btn btn-primary" @click="login">Đăng nhập</button>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const email = ref('')
const password = ref('')
const router = useRouter()

function login() {
  if (email.value && password.value) {
    router.push('/posts')
  }
}
</script>
