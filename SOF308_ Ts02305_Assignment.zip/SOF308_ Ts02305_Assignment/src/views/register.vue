<template>
  <h3>Đăng ký</h3>

  <input class="form-control mb-2" placeholder="Tên">
  <input class="form-control mb-2" placeholder="Email">
  <input class="form-control mb-2" type="password" placeholder="Mật khẩu">

  <button class="btn btn-success">Đăng ký</button>
</template>
