<template>
  <div class="container mt-4">
    <h3>📝 Đăng bài viết</h3>

    <!-- ===== BƯỚC 1: ĐĂNG BÀI ===== -->
    <form @submit.prevent="addPost" class="card p-3 mb-4">
      <input
        v-model="newPost.title"
        class="form-control mb-2"
        placeholder="Tiêu đề"
        required
      />
      <textarea
        v-model="newPost.content"
        class="form-control mb-2"
        placeholder="Nội dung"
        required
      ></textarea>
      <button class="btn btn-primary">Đăng bài</button>
    </form>

    <!-- ===== BƯỚC 2: DANH SÁCH + BÌNH LUẬN ===== -->
    <div v-for="post in posts" :key="post.id" class="card mb-3">
      <div class="card-body">
        <h5>{{ post.title }}</h5>
        <p>{{ post.content }}</p>

        <button
          class="btn btn-danger btn-sm mb-2"
          @click="removePost(post.id)"
        >
          Xóa bài
        </button>

        <h6>Bình luận</h6>
        <ul class="list-group mb-2">
          <li
            v-for="(cmt, index) in post.comments"
            :key="index"
            class="list-group-item"
          >
            {{ cmt }}
          </li>
        </ul>

        <form @submit.prevent="addComment(post)">
          <input
            v-model="post.newComment"
            class="form-control mb-2"
            placeholder="Nhập bình luận..."
          />
          <button class="btn btn-secondary btn-sm">Gửi</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const posts = ref([])

const newPost = ref({
  title: '',
  content: ''
})

onMounted(() => {
  const saved = localStorage.getItem('posts')
  if (saved) posts.value = JSON.parse(saved)
})

function save() {
  localStorage.setItem('posts', JSON.stringify(posts.value))
}

// ===== BƯỚC 1 =====
function addPost() {
  posts.value.unshift({
    id: Date.now(),
    title: newPost.value.title,
    content: newPost.value.content,
    comments: [],
    newComment: ''
  })

  newPost.value.title = ''
  newPost.value.content = ''
  save()
}
// ===== BƯỚC 2 =====
function addComment(post) {
  if (!post.newComment) return
  post.comments.push(post.newComment)
  post.newComment = ''
  save()
}

function removePost(id) {
  posts.value = posts.value.filter(p => p.id !== id)
  save()
}
</script>
