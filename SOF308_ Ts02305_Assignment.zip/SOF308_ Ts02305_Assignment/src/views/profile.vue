<template>
  <h3>Thông tin cá nhân</h3>

  <input class="form-control mb-2" v-model="name">
  <input class="form-control mb-2" v-model="email">

  <button class="btn btn-primary">Lưu</button>
</template>

<script setup>
import { ref } from 'vue'

const name = ref('Sinh viên FPT')
const email = ref('sv@fpt.edu.vn')
</script>
